"""Simple test to verify pytest is working"""

def test_simple():
    """Simple test"""
    assert True
